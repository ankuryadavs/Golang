package main

import "fmt"

func main()  {

	var number uint16=260
	fmt.Println("Hello World",number)
	
}